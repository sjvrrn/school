@extends('layouts.default')
@section('content')
 
<div class="container">
  <div class="row panel">
  <div class="col-md-3">
  <img src="img/profile.png" class="img-responsive" width="" height="">
  </div>
  <div class="col-md-9">
  <div class="row">
  <div class="col-md-3">Name</div>
  <div class="col-md-9"><?php echo $users->name;?></div>
  </div>
    <div class="row">
  <div class="col-md-3">Email</div>
  <div class="col-md-9"><?php echo $users->email;?></div>
  </div>
    <div class="row">
  <div class="col-md-3">created_at</div>
  <div class="col-md-9"><?php echo $users->created_at;?></div>
  </div>
  <div class="row">
  <div class="col-md-3">updated_at</div>
  <div class="col-md-9"><?php echo $users->updated_at;?></div>
  </div>
  </div>
  </div>
</div>

<div class="sidenav">
  <a href="#about">About</a>
  <a href="#services">Services</a>
  <a href="#clients">Clients</a>
  <a href="#contact">Contact</a>
</div>

@stop