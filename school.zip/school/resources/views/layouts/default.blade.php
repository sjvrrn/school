<!doctype html>
<html>
<head>
   @include('includes.head')
   @include('includes.header')
</head>
<body>
<div class="container">
   <div class="container">
   @include('includes.menu')
   <div id="main" class="row">
           @yield('content')
   </div>
   <footer class="row">
       @include('includes.footer')
   </footer>
</div>
</div>
</body>
</html>