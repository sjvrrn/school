<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="#">ContactUs</a></li>
      <li><a href="#">AboutUs</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a type="button" class="btn" data-toggle="modal" data-target="#signup">SignUp</a></li>
      <li><a type="button" class="btn" data-toggle="modal" data-target="#login">Login</a></li>
    </ul>
  </div>
</nav>



<!-- Modal signup -->
<div id="signup" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Register</h4>
      </div>
      <div class="modal-body">
       <form class="form-horizontal" role="form" method="post" action="/register">

<div class="form-group">
<label for="userName" class="col-sm-2 control-label">Name:</label>
<div class="col-sm-6">
<input type="text" name="name" class="form-control" id="userName" placeholder="User Name">
</div>
</div>
 <div class="form-group">
<label for="userName" class="col-sm-2 control-label">Email:</label>
<div class="col-sm-6">
<input type="email" name="email" class="form-control" id="userName" placeholder="Email">
</div>
</div>
<div class="form-group">
<label for="passwd" class="col-sm-2 control-label">Password:</label>
<div class="col-sm-6">
<input type="password" name="password" class="form-control" id="passwd" placeholder="Password">
</div>
</div>
 <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
<div class="form-group">
<div class="col-sm-offset-2 col-sm-10">
<button type="submit" class="btn btn-primary" id="register">Register</button>
</div>
</div>
 
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<!--login-->

<!-- Modal -->
<div id="login" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Login</h4>
      </div>
      <div class="modal-body">
       <form class="form-horizontal" role="form" method="post" action="/login">

 <div class="form-group">
<label for="userName" class="col-sm-2 control-label">Email:</label>
<div class="col-sm-6">
<input type="email" name="email" class="form-control" id="userName" placeholder="Email">
</div>
</div>
<div class="form-group">
<label for="passwd" class="col-sm-2 control-label">Password:</label>
<div class="col-sm-6">
<input type="password" name="password" class="form-control" id="passwd" placeholder="Password">
</div>
</div>
 <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
<div class="form-group">
<div class="col-sm-offset-2 col-sm-10">
<button type="submit" class="btn btn-primary" id="register">Login</button>
</div>
</div>
 
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>